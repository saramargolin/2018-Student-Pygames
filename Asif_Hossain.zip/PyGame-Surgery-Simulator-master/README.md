# Surgery Simulator
<h2> Images </h2>
<img align= left Src="https://github.com/ahossain777/PyGame-Surgery-Simulator/blob/master/Capture.PNG" width=300 height=300>
<img align= left Src="https://github.com/ahossain777/PyGame-Surgery-Simulator/blob/master/Capture2.PNG" width=300 height=300>
<img align= left Src="https://github.com/ahossain777/PyGame-Surgery-Simulator/blob/master/Capture3.PNG" width=300 height=300>
<img align= left Src="https://github.com/ahossain777/PyGame-Surgery-Simulator/blob/master/Capture4.PNG" width=300 height=300>
<h2> Description </h2>
<p> This game is simulation of a surgery. Use your mouse to operate on the patient by clicking and dragging the organs into the patients body. There is a time limit of 20 seconds, you have to complete withing the time limit or else the patient will die. </p>  
